﻿
namespace BowlingBall.Domain.Enum
{
    public enum FrameType
    {
        Unknown = 0,
        Normal = 1,
        Spare = 2,
        Strike = 3
    }
}
