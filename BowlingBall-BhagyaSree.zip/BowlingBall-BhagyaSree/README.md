# BowlingBall
This is the bowling game score calculator done in C#
